
import plotly.graph_objects as go

# Maturity data
dimensions = ["Strategic\nClarity", "Technical\nArchitecture", "Ethical\nFramework", "Business\nModel", "Execution\nReadiness"]
previous = [30, 45, 30, 0, 0]
current = [95, 85, 85, 90, 90]

# Calculate improvements for hover data
improvements = [c - p for c, p in zip(current, previous)]

# Create radar chart
fig = go.Figure()

# Add Previous (Nov 12) trace
fig.add_trace(go.Scatterpolar(
    r=previous,
    theta=dimensions,
    fill='toself',
    name='Nov 12',
    line=dict(color='#DB4545', width=3),
    fillcolor='rgba(219, 69, 69, 0.15)',
    hovertemplate='<b>%{theta}</b><br>Nov 12: %{r}%<extra></extra>'
))

# Add Current (Dec 10) trace
fig.add_trace(go.Scatterpolar(
    r=current,
    theta=dimensions,
    fill='toself',
    name='Dec 10',
    line=dict(color='#1FB8CD', width=3),
    fillcolor='rgba(31, 184, 205, 0.15)',
    hovertemplate='<b>%{theta}</b><br>Dec 10: %{r}%<extra></extra>'
))

# Update layout
fig.update_layout(
    title={
        'text': "VerifiMind-PEAS Maturity Growth Across Dimensions (Nov-Dec)<br><span style='font-size: 18px; font-weight: normal;'>Business Model & Execution rose from 0% to 90% in one month</span>"
    },
    polar=dict(
        radialaxis=dict(
            visible=True,
            range=[0, 100],
            ticksuffix='%',
            tickmode='linear',
            tick0=0,
            dtick=25,
            showline=True,
            linewidth=1
        ),
        angularaxis=dict(
            linewidth=1,
            showline=True
        )
    ),
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.05,
        xanchor='center',
        x=0.5
    )
)

# Save as PNG and SVG
fig.write_image('verifimind_maturity.png')
fig.write_image('verifimind_maturity.svg', format='svg')
